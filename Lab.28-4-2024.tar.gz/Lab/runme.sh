# Create a file for the fortune cookies
echo "Try Harder - Offensive Security
%
Maybe this world is another planet’s hell. — Aldous Huxley
%
Choices are the hinges of destiny. —Edwin Markham
%
Sometimes it’s the smallest decisions that can 
change your life forever. —Keri Russell
%
Life is either a daring adventure or nothing. -Helen Keller
%
Life is a long lesson in humility. -James M. Barrie
%
In three words I can sum up everything I've learned about life: it goes on. -Robert Frost
%
You have brains in your head. You have feet in your shoes. You can steer yourself any direction you choose. -Dr. Seuss
%
Life is made of ever so many partings welded together. -Charles Dickens
%
Your time is limited, so don't waste it living someone else's life. Don't be trapped by dogma — which is living with the results of other people's thinking. -Steve Jobs
%
Life is trying things to see if they work. -Ray Bradbury
%
You will face many defeats in life, but never let yourself be defeated. -Maya Angelou
%
Go confidently in the direction of your dreams! Live the life you've imagined. -Henry David Thoreau
%
In the end, it's not the years in your life that count. It's the life in your years. -Abraham Lincoln
%
Never let the fear of striking out keep you from playing the game. -Babe Ruth
%
In this life we cannot do great things. We can only do small things with great love. -Mother Teresa
%
Many of life's failures are people who did not realize how close they were to success when they gave up. -Thomas A. Edison
%
You have brains in your head. You have feet in your shoes. You can steer yourself any direction you choose. -Dr. Seuss
%
Success is not final; failure is not fatal: It is the courage to continue that counts. -Winston S. Churchill
%
Success usually comes to those who are too busy to be looking for it. -Henry David Thoreau
%
If you want to make your dreams come true, the first thing you have to do is wake up. -J.M. Power
%
If you really look closely, most overnight successes took a long time. -Steve Jobs
%
The secret of success is to do the common thing uncommonly well. -John D. Rockefeller Jr.
%
I find that the harder I work, the more luck I seem to have. -Thomas Jefferson
%
The future belongs to those who believe in the beauty of their dreams. -Eleanor Roosevelt
%
We are the creative force of our life, and through our  own decisions rather than our conditions, if we carefully
learn to do certain things, we can accomplish those goals. —Stephen Covey" > quotes

strfile -c % quotes quotes.dat > /dev/null 2>&1

fortune quotes

# rm quotes.dat 

cat /etc/machine-id
